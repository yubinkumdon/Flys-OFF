// Configurations for flies
const flyCount = 10; // Number of flies
const flyContainer = document.getElementById("fly-container");

// Random position generator
function getRandomPosition() {
    const x = Math.floor(Math.random() * window.innerWidth);
    const y = Math.floor(Math.random() * window.innerHeight);
    return { x, y };
}

// Randomly create and place flies on the screen
function createFlies() {
    for (let i = 0; i < flyCount; i++) {
        const fly = document.createElement("div");
        fly.classList.add("fly");
        
        const { x, y } = getRandomPosition();
        fly.style.left = `${x}px`;
        fly.style.top = `${y}px`;
        
        // Assign random movement for each fly
        animateFly(fly);
        flyContainer.appendChild(fly);
    }
}

// Randomly move flies in random patterns
function animateFly(fly) {
    const moveInterval = Math.random() * 2000 + 1000; // Interval between moves

    setInterval(() => {
        const { x, y } = getRandomPosition();
        fly.style.transform = `translate(${x - fly.offsetLeft}px, ${y - fly.offsetTop}px)`;
    }, moveInterval);
}

// Initialize flies on page load
createFlies();
